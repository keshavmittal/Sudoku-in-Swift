//
//  SudokuCollectionViewCell.swift
//  Sudoku
//
//  Created by Keshav -MAC on 2016-10-09.
//  Copyright © 2016 Keshav -MAC. All rights reserved.
//

import UIKit

class SudokuCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var Label: UILabel!

}
